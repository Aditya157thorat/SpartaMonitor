COLORS = {
    "bg_dark": "#0e0e0f",
    "red": "#c92a2a",
    "soft_red": "#e03131",
    "ink": "#111",
}
